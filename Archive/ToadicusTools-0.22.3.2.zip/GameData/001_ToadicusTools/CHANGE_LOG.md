# Toadicus Tools :: Change Log

0.22.3.1
	changed namespace of TweakableTools

0.22.3
	updated for 1.4

0.22.2
	Deleted dll

0.22.1
	Updated for 1.3

0.22.0
	PartExtensions: Implemented manual staging search for isInStagingList.
