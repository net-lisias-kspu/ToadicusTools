# Toadicus Tools :: Change Log

* 2018-1012: 0.22.3.3 (Lisias) for KSP 1.4
	+ "Emergency" update: coping with KSPe 2.0 final Interface
* 2018-0816: 0.22.3.2 (Lisias) for KSP 1.4.x
	+ Config xml files are now saved under <KSP_ROOT>/PluginData Hierarchy.
		- Add hard dependency for [KSP API Extensions**/L**](https://github.com/net-lisias-ksp/KSPAPIExtensions). 
* 2018-0427: 0.22.3.1 (linuxgurugamer) for KSP 1.4.2
	+ changed namespace of TweakableTools
* 2018-0427: 0.22.3 (linuxgurugamer) for KSP 1.4.2
	+ Updated for 1.4+
* 2017-1011: 0.22.2 (linuxgurugamer) for KSP 1.3.1
	+ Updated for KSP 1.3.1
* 2017-0529: 0.22.1 (linuxgurugamer) for KSP 1.3.0
	+ updated for 1.3
* 2016-1115: 0.22.0 (linuxgurugamer) for KSP 1.2.2
	+ No changelog provided
* 2016-0912: 21 (toadicus) for KSP 1.1.3
	+ No changelog provided
* 2016-0430: 20 (toadicus) for KSP 1.1.2
	+ No changelog provided
* 2016-0423: 19 (toadicus) for KSP 1.1
	+ No changelog provided
* 2016-0227: 18 (toadicus) for KSP 1.0.5
	+ No changelog provided
